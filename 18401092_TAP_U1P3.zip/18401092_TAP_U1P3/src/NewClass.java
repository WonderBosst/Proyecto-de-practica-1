/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Maxi9
 */
public class NewClass {
   private String SO, marca, modelo, memoria, cargador, audifonos, funda, mica;
   
   public NewClass (){
   this.SO="IOS";
   this.audifonos="SI";
   this.cargador="SI";
   this.funda="SI";
   this.marca="APPLE";
   this.memoria="32_GB";
   this.modelo="RTX360";
   this.mica="SI";
   }
   
   NewClass(String marca, String modelo, String memoria, String SO, String cargador, String funda, String audifonos, String mica){
   this.marca=marca; this.modelo=modelo; this.memoria=memoria; this.SO=SO; this.cargador=cargador; this.funda=funda;
   this.audifonos=audifonos; this.mica=mica;
   }

    public String getSO() {
        return SO;
    }

    public void setSO(String SO) {
        this.SO = SO;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getMemoria() {
        return memoria;
    }

    public void setMemoria(String memoria) {
        this.memoria = memoria;
    }

    public String getCargador() {
        return cargador;
    }

    public void setCargador(String cargador) {
        this.cargador = cargador;
    }

    public String getAudifonos() {
        return audifonos;
    }

    public void setAudifonos(String audifonos) {
        this.audifonos = audifonos;
    }

    public String getFunda() {
        return funda;
    }

    public void setFunda(String funda) {
        this.funda = funda;
    }

    public String getMica() {
        return mica;
    }

    public void setMica(String mica) {
        this.mica = mica;
    }
   
   
}
