/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Maxi9
 */
public class NewClass {
    private int id_trabajador, telefono;
    private float money;
    private String nombre, apellidos, correo, genero;
    
    public NewClass() {
        this.id_trabajador = 101010;
        this.telefono = 311;
        this.money = 9;
        this.nombre = "Hola";
        this.apellidos = "Cualquiera";
        this.correo = "@hola otra vez";
        this.genero = "Genero";
    }
    public NewClass(int id_trabajador, String nombre, String apellidos, int telefono, String correo, float money, String genero){
    this.id_trabajador = id_trabajador; this.nombre = nombre; this.apellidos = apellidos; this.correo = correo; this.money = money;
    this.genero = genero;
    }

    public int getId_trabajador() {
        return id_trabajador;
    }

    public void setId_trabajador(int id_trabajador) {
        this.id_trabajador = id_trabajador;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public float getMoney() {
        return money;
    }

    public void setMoney(float money) {
        this.money = money;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }
   
}
