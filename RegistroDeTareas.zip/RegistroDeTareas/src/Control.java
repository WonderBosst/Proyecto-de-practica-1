/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Maxi9
 */
public class Control {
    private String Tarea, Fecha, Materia;
    
public Control(){
    this.Tarea = "Luego sabremos";
    this.Fecha = "Luego sabremos";
    this.Materia = "Luego sabremos";
}

Control(String Tarea, String Fecha, String Materia) {
     this.Tarea=Tarea; this.Fecha=Fecha;
     this.Materia=Materia;
    }

    public String getTarea() {
        return Tarea;
    }

    public void setTarea(String Tarea) {
        this.Tarea = Tarea;
    }

    public String getFecha() {
        return Fecha;
    }

    public void setFecha(String Fecha) {
        this.Fecha = Fecha;
    }

    public String getMateria() {
        return Materia;
    }

    public void setMateria(String Materia) {
        this.Materia = Materia;
    }


}
